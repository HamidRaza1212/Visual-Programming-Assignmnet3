using Assignment_3.Data;
using Assignment_3.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Assignment_3.Controllers
{
    [Authorize(Roles = "Employee")]
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public EmployeeController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Employee/ApplyLeave
        public IActionResult ApplyLeave()
        {
            return View(new LeaveModel());
        }

        // POST: Employee/ApplyLeave
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApplyLeave(LeaveModel model)
        {
            // Get current logged-in user
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Find employee record
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);

            if (employee == null)
            {
                TempData["Error"] = "Employee record not found.";
                return RedirectToAction("MyProfile");
            }

            // Set the EmployeeId from logged-in user
            model.EmployeeId = employee.EmployeeId;
            model.CreatedDate = DateTime.Now;
            model.Status = LeaveStatus.Pending;

            // Remove Employee from ModelState validation since we set it manually
            ModelState.Remove("Employee");
            ModelState.Remove("EmployeeId");

            if (ModelState.IsValid)
            {
                // Validate dates
                if (model.EndDate < model.StartDate)
                {
                    TempData["Error"] = "End date cannot be before start date.";
                    return View(model);
                }

                if (model.StartDate < DateTime.Today)
                {
                    TempData["Error"] = "Start date cannot be in the past.";
                    return View(model);
                }

                _context.LeaveRequests.Add(model);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Leave request submitted successfully!";
                return RedirectToAction("MyLeaves");
            }

            return View(model);
        }

        // GET: Employee/MyLeaves
        public async Task<IActionResult> MyLeaves()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);

            if (employee == null)
            {
                TempData["Error"] = "Employee record not found.";
                return View(new List<LeaveModel>());
            }

            var leaves = await _context.LeaveRequests
                .Where(l => l.EmployeeId == employee.EmployeeId)
                .OrderByDescending(l => l.CreatedDate)
                .ToListAsync();

            return View(leaves);
        }

        // GET: Employee/MyProfile
        public async Task<IActionResult> MyProfile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);

            if (employee == null)
            {
                TempData["Error"] = "Employee record not found.";
                return RedirectToAction("Login", "Account");
            }

            return View(employee);
        }

        // GET: Employee/EditLeave
        public async Task<IActionResult> EditLeave(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);

            var leave = await _context.LeaveRequests
                .FirstOrDefaultAsync(l => l.LeaveId == id && l.EmployeeId == employee.EmployeeId);

            if (leave == null)
            {
                TempData["Error"] = "Leave request not found.";
                return RedirectToAction("MyLeaves");
            }

            if (leave.Status != LeaveStatus.Pending)
            {
                TempData["Error"] = "Only pending leave requests can be edited.";
                return RedirectToAction("MyLeaves");
            }

            return View(leave);
        }

        // POST: Employee/EditLeave
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditLeave(int id, LeaveModel model)
        {
            var user = await _userManager.GetUserAsync(User);
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);

            var leave = await _context.LeaveRequests
                .FirstOrDefaultAsync(l => l.LeaveId == id && l.EmployeeId == employee.EmployeeId);

            if (leave == null)
            {
                TempData["Error"] = "Leave request not found.";
                return RedirectToAction("MyLeaves");
            }

            if (leave.Status != LeaveStatus.Pending)
            {
                TempData["Error"] = "Only pending leave requests can be edited.";
                return RedirectToAction("MyLeaves");
            }

            // Remove validations for fields we're not updating
            ModelState.Remove("Employee");
            ModelState.Remove("EmployeeId");

            if (ModelState.IsValid)
            {
                if (model.EndDate < model.StartDate)
                {
                    TempData["Error"] = "End date cannot be before start date.";
                    return View(model);
                }

                leave.LeaveType = model.LeaveType;
                leave.StartDate = model.StartDate;
                leave.EndDate = model.EndDate;
                leave.Reason = model.Reason;

                await _context.SaveChangesAsync();

                TempData["Success"] = "Leave request updated successfully!";
                return RedirectToAction("MyLeaves");
            }

            return View(leave);
        }

        // POST: Employee/CancelLeave
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelLeave(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.IdentityUserId == user.Id);

            var leave = await _context.LeaveRequests
                .FirstOrDefaultAsync(l => l.LeaveId == id && l.EmployeeId == employee.EmployeeId);

            if (leave == null)
            {
                TempData["Error"] = "Leave request not found.";
                return RedirectToAction("MyLeaves");
            }

            if (leave.Status != LeaveStatus.Pending)
            {
                TempData["Error"] = "Only pending leave requests can be cancelled.";
                return RedirectToAction("MyLeaves");
            }

            _context.LeaveRequests.Remove(leave);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave request cancelled successfully!";
            return RedirectToAction("MyLeaves");
        }
    }
}