﻿using Assignment_3.Data;
using Assignment_3.Models;
using Assignment_3.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace Assignment_3.Controllers
{
  
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AdminController(
            ApplicationDbContext context,
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager)
        {
            _context = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        // GET: Admin/Dashboard
        public async Task<IActionResult> Dashboard()
        {
            var viewModel = new DashboardViewModel
            {
                TotalEmployees = await _context.Employees.CountAsync(),
                ActiveEmployees = await _context.Employees.CountAsync(e => e.IsActive),
                InactiveEmployees = await _context.Employees.CountAsync(e => !e.IsActive),
                PendingLeaves = await _context.LeaveRequests.CountAsync(l => l.Status == LeaveStatus.Pending),
                ApprovedLeaves = await _context.LeaveRequests.CountAsync(l => l.Status == LeaveStatus.Approved),
                RejectedLeaves = await _context.LeaveRequests.CountAsync(l => l.Status == LeaveStatus.Rejected),
                RecentLeaves = await _context.LeaveRequests
                    .Include(l => l.Employee)
                    .OrderByDescending(l => l.CreatedDate)
                    .Take(5)
                    .ToListAsync()
            };

            return View(viewModel);
        }

        // GET: Admin/Employees
        public async Task<IActionResult> Employees()
        {
            var employees = await _context.Employees
                .Include(e => e.IdentityUser)
                .OrderByDescending(e => e.IsActive)
                .ThenBy(e => e.Name)
                .ToListAsync();

            return View(employees);
        }

        // GET: Admin/CreateEmployee
        public IActionResult CreateEmployee()
        {
            return View();
        }

        // POST: Admin/CreateEmployee
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateEmployee(CreateEmployeeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Check if CNIC already exists
            if (await _context.Employees.AnyAsync(e => e.CNIC == model.CNIC))
            {
                ModelState.AddModelError("CNIC", "An employee with this CNIC already exists.");
                return View(model);
            }

            // Check if Email already exists
            if (await _userManager.FindByEmailAsync(model.Email) != null)
            {
                ModelState.AddModelError("Email", "An employee with this email already exists.");
                return View(model);
            }

            // Create Identity User
            var identityUser = new IdentityUser
            {
                UserName = model.Email,
                Email = model.Email,
                EmailConfirmed = true
            };

            var result = await _userManager.CreateAsync(identityUser, model.Password);

            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return View(model);
            }

            // Assign role to user
            await _userManager.AddToRoleAsync(identityUser, model.Role);

            // Create Employee
            var employee = new EmployeeModel
            {
                Name = model.Name,
                CNIC = model.CNIC,
                Email = model.Email,
                Department = model.Department,
                Designation = model.Designation,
                IsActive = model.IsActive,
                IdentityUserId = identityUser.Id
            };

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            TempData["Success"] = $"Employee {model.Name} created successfully.";
            return RedirectToAction(nameof(Employees));
        }

        // GET: Admin/EditEmployee/5
        public async Task<IActionResult> EditEmployee(int id)
        {
            var employee = await _context.Employees.FindAsync(id);

            if (employee == null)
            {
                return NotFound();
            }

            var viewModel = new EditEmployeeViewModel
            {
                EmployeeId = employee.EmployeeId,
                Name = employee.Name,
                CNIC = employee.CNIC,
                Email = employee.Email,
                Department = employee.Department,
                Designation = employee.Designation,
                IsActive = employee.IsActive,
                IdentityUserId = employee.IdentityUserId
            };

            return View(viewModel);
        }

        // POST: Admin/EditEmployee/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditEmployee(EditEmployeeViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var employee = await _context.Employees.FindAsync(model.EmployeeId);

            if (employee == null)
            {
                return NotFound();
            }

            // Update allowed fields
            employee.Name = model.Name;
            employee.Department = model.Department;
            employee.Designation = model.Designation;
            employee.IsActive = model.IsActive;

            _context.Update(employee);
            await _context.SaveChangesAsync();

            TempData["Success"] = $"Employee {model.Name} updated successfully.";
            return RedirectToAction(nameof(Employees));
        }

        // GET: Admin/LeaveRequests
        public async Task<IActionResult> LeaveRequests()
        {
            var leaves = await _context.LeaveRequests
                .Include(l => l.Employee)
                .OrderByDescending(l => l.CreatedDate)
                .ToListAsync();

            return View(leaves);
        }

        // GET: Admin/EditLeave/5
        public async Task<IActionResult> EditLeave(int id)
        {
            var leave = await _context.LeaveRequests
                .Include(l => l.Employee)
                .FirstOrDefaultAsync(l => l.LeaveId == id);

            if (leave == null)
            {
                return NotFound();
            }

            return View(leave);
        }

        // POST: Admin/EditLeave/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditLeave(LeaveModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var leave = await _context.LeaveRequests.FindAsync(model.LeaveId);

            if (leave == null)
            {
                return NotFound();
            }

            // Update leave details
            leave.LeaveType = model.LeaveType;
            leave.StartDate = model.StartDate;
            leave.EndDate = model.EndDate;
            leave.Reason = model.Reason;
            leave.Status = model.Status;

            _context.Update(leave);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave request updated successfully.";
            return RedirectToAction(nameof(LeaveRequests));
        }

        // POST: Admin/ApproveLeave/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveLeave(int id)
        {
            var leave = await _context.LeaveRequests.FindAsync(id);

            if (leave == null)
            {
                return NotFound();
            }

            leave.Status = LeaveStatus.Approved;
            _context.Update(leave);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave request approved successfully.";
            return RedirectToAction(nameof(LeaveRequests));
        }

        // POST: Admin/RejectLeave/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectLeave(int id)
        {
            var leave = await _context.LeaveRequests.FindAsync(id);

            if (leave == null)
            {
                return NotFound();
            }

            leave.Status = LeaveStatus.Rejected;
            _context.Update(leave);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Leave request rejected.";
            return RedirectToAction(nameof(LeaveRequests));
        }
    }
}