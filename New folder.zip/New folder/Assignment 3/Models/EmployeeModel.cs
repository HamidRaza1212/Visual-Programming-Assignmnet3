﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assignment_3.Models
{
   
    public class EmployeeModel
    {
        [Key]
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "CNIC is required")]
        [StringLength(15, ErrorMessage = "CNIC must be 13-15 characters", MinimumLength = 13)]
        [RegularExpression(@"^\d{5}-\d{7}-\d{1}$", ErrorMessage = "CNIC format must be XXXXX-XXXXXXX-X")]
        [Display(Name = "CNIC")]
        public string CNIC { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [StringLength(100)]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Department is required")]
        [StringLength(50)]
        [Display(Name = "Department")]
        public string Department { get; set; }

        [Required(ErrorMessage = "Designation is required")]
        [StringLength(50)]
        [Display(Name = "Designation")]
        public string Designation { get; set; }

        [Display(Name = "Active Status")]
        public bool IsActive { get; set; } = true;

        // Foreign key to ASP.NET Core Identity
        [Required]
        [Display(Name = "Identity User ID")]
        public string IdentityUserId { get; set; }

        // Navigation property to Identity User
        [ForeignKey("IdentityUserId")]
        public virtual Microsoft.AspNetCore.Identity.IdentityUser IdentityUser { get; set; }

        // Navigation property for leave requests
        public virtual ICollection<LeaveModel> LeaveRequests { get; set; }
    }
}