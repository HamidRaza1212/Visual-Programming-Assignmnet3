﻿using Assignment_3.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Assignment_3.Data
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser, IdentityRole, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // DbSet for Employees
        public DbSet<EmployeeModel> Employees { get; set; }

        // DbSet for Leave Requests
        public DbSet<LeaveModel> LeaveRequests { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // CRITICAL: Must be called first

            // Configure Employee entity
            modelBuilder.Entity<EmployeeModel>(entity =>
            {
                // Create unique index on CNIC
                entity.HasIndex(e => e.CNIC)
                    .IsUnique()
                    .HasDatabaseName("IX_Employee_CNIC");

                // Create unique index on Email
                entity.HasIndex(e => e.Email)
                    .IsUnique()
                    .HasDatabaseName("IX_Employee_Email");

                // Configure relationship with Identity User
                entity.HasOne(e => e.IdentityUser)
                    .WithMany()
                    .HasForeignKey(e => e.IdentityUserId)
                    .OnDelete(DeleteBehavior.Restrict);

                // Configure relationship with Leave Requests
                entity.HasMany(e => e.LeaveRequests)
                    .WithOne(l => l.Employee)
                    .HasForeignKey(l => l.EmployeeId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure Leave entity
            modelBuilder.Entity<LeaveModel>(entity =>
            {
                // Set default value for CreatedDate
                entity.Property(l => l.CreatedDate)
                    .HasDefaultValueSql("GETDATE()");

                // Set default value for Status
                entity.Property(l => l.Status)
                    .HasDefaultValue(LeaveStatus.Pending);

                // Create index on EmployeeId for faster queries
                entity.HasIndex(l => l.EmployeeId)
                    .HasDatabaseName("IX_Leave_EmployeeId");

                // Create index on Status for filtering
                entity.HasIndex(l => l.Status)
                    .HasDatabaseName("IX_Leave_Status");
            });
        }
    }
}