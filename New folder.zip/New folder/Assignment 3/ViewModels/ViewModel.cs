﻿using Assignment_3.Models;
using System.ComponentModel.DataAnnotations;


namespace Assignment_3.ViewModels
{
   
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me")]
        public bool RememberMe { get; set; }
    }

    /// <summary>
    /// ViewModel for creating a new employee
    /// </summary>
    public class CreateEmployeeViewModel
    {
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "CNIC is required")]
        [StringLength(15, MinimumLength = 13)]
        [RegularExpression(@"^\d{5}-\d{7}-\d{1}$", ErrorMessage = "CNIC format must be XXXXX-XXXXXXX-X")]
        [Display(Name = "CNIC")]
        public string CNIC { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [StringLength(100, ErrorMessage = "Password must be at least {2} characters", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm password is required")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Password and confirmation do not match")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Department is required")]
        [StringLength(50)]
        [Display(Name = "Department")]
        public string Department { get; set; }

        [Required(ErrorMessage = "Designation is required")]
        [StringLength(50)]
        [Display(Name = "Designation")]
        public string Designation { get; set; }

        [Required(ErrorMessage = "Role is required")]
        [Display(Name = "Role")]
        public string Role { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;
    }

    /// <summary>
    /// ViewModel for editing employee
    /// </summary>
    public class EditEmployeeViewModel
    {
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100)]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Display(Name = "CNIC (Cannot be changed)")]
        public string CNIC { get; set; }

        [Display(Name = "Email (Cannot be changed)")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Department is required")]
        [StringLength(50)]
        [Display(Name = "Department")]
        public string Department { get; set; }

        [Required(ErrorMessage = "Designation is required")]
        [StringLength(50)]
        [Display(Name = "Designation")]
        public string Designation { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; }

        public string IdentityUserId { get; set; }
    }

    /// <summary>
    /// ViewModel for employee self-update (limited fields)
    /// </summary>
    public class UpdateProfileViewModel
    {
        public int EmployeeId { get; set; }

        [Display(Name = "Full Name (Cannot be changed)")]
        public string Name { get; set; }

        [Display(Name = "CNIC (Cannot be changed)")]
        public string CNIC { get; set; }

        [Display(Name = "Email (Cannot be changed)")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Department is required")]
        [StringLength(50)]
        [Display(Name = "Department")]
        public string Department { get; set; }

        [Required(ErrorMessage = "Designation is required")]
        [StringLength(50)]
        [Display(Name = "Designation")]
        public string Designation { get; set; }
    }

    /// <summary>
    /// ViewModel for dashboard statistics
    /// </summary>
    public class DashboardViewModel
    {
        public int TotalEmployees { get; set; }
        public int ActiveEmployees { get; set; }
        public int InactiveEmployees { get; set; }
        public int PendingLeaves { get; set; }
        public int ApprovedLeaves { get; set; }
        public int RejectedLeaves { get; set; }
        public List<LeaveModel> RecentLeaves { get; set; }
    }
}